# 0.2.9

* new implementations of `select`, `rename`, and `mutate` (for unitted data) to
keep up with changes to the tidyverse

# 0.2.8 and previous

* we weren't tracking news until 0.2.9, sorry!
